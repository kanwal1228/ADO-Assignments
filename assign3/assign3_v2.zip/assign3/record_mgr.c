/*
 * record_mgr.c
 *
 *  Created on: Apr 6, 2015
 *      Author: kanwal
 */

#include "expr.h"
#include "test_helper.h"
#include "buffer_mgr.h"
#include "storage_mgr.h"
#include "record_mgr.h"

// dynamic string
typedef struct VarString {
  char *buf;
  int size;
  int bufsize;
} VarString;

#define MAKE_VARSTRING(var)				\
  do {							\
  var = (VarString *) malloc(sizeof(VarString));	\
  var->size = 0;					\
  var->bufsize = 100;					\
  var->buf = malloc(100);				\
  } while (0)

#define FREE_VARSTRING(var)			\
  do {						\
  free(var->buf);				\
  free(var);					\
  } while (0)

#define GET_STRING(result, var)			\
  do {						\
    result = malloc((var->size) + 1);		\
    memcpy(result, var->buf, var->size);	\
    result[var->size] = '\0';			\
  } while (0)

#define RETURN_STRING(var)			\
  do {						\
    char *resultStr;				\
    GET_STRING(resultStr, var);			\
    FREE_VARSTRING(var);			\
    return resultStr;				\
  } while (0)

#define ENSURE_SIZE(var,newsize)				\
  do {								\
    if (var->bufsize < newsize)					\
    {								\
      int newbufsize = var->bufsize;				\
      while((newbufsize *= 2) < newsize);			\
      var->buf = realloc(var->buf, newbufsize);			\
    }								\
  } while (0)

#define APPEND_STRING(var,string)					\
  do {									\
    ENSURE_SIZE(var, var->size + strlen(string));			\
    memcpy(var->buf + var->size, string, strlen(string));		\
    var->size += strlen(string);					\
  } while(0)

#define APPEND(var, ...)			\
  do {						\
    char *tmp = malloc(10000);			\
    sprintf(tmp, __VA_ARGS__);			\
    APPEND_STRING(var,tmp);			\
    free(tmp);					\
  } while(0)




//structure to use the buffer Manager

typedef struct Buffer_mgr
{
	BM_BufferPool *bm;
	BM_PageHandle *h;
	int totalRecords;
	int insertAt;

}Buffer_mgr;

char * serializeRec(Record *record, Schema *schema)
{
  VarString *result;
  MAKE_VARSTRING(result);
  int i;

  APPEND(result, "[%i-%i] (", record->id.page, record->id.slot);

  for(i = 0; i < schema->numAttr; i++)
    {
	  APPEND(result, "%s", (i == 0) ? "" : ",");
      APPEND_STRING(result, serializeAttr (record, schema, i));
    }

  APPEND_STRING(result, ")");

  RETURN_STRING(result);
}


//no. of bytes to be copied

int noOfBytes(DataType dt,int typeLength)
{
	int bytestoCopy = 0;
	switch (dt)
	{
		case DT_STRING:
		  bytestoCopy = typeLength + 1;
		  break;
		case DT_INT:
		  bytestoCopy = sizeof(int);
		  break;
		case DT_FLOAT:
		  bytestoCopy = sizeof(float);
		  break;
		case DT_BOOL:
		  bytestoCopy = sizeof(bool);
		break;
	}

	return bytestoCopy;
}


//to calculate the offset
//method copied from rm_serializer.c
RC
attrOffset (Schema *schema, int attrNum, int *result)
{
  int offset = 0;
  int attrPos = 0;

  for(attrPos = 0; attrPos < attrNum; attrPos++)
    switch (schema->dataTypes[attrPos])
      {
      case DT_STRING:
	offset += ( schema->typeLength[attrPos]+1);
	break;
      case DT_INT:
	offset += sizeof(int);
	break;
      case DT_FLOAT:
	offset += sizeof(float);
	break;
      case DT_BOOL:
	offset += sizeof(bool);
	break;
      }

  *result = offset;
  return RC_OK;
}

//deserialize the schema written to the pagefile

Schema* deserializeSchema(char* data)
{
	int numAttr,i;
	char **attrNames;
	char *keyName;
	char **dataTypes;
	DataType *dt;
	int *keys = NULL;
	int *typelength;

	char *dataChar = malloc(sizeof(char));
	char dataStr[10];

	sscanf(data,"%*s %*s <%d> %*s",&numAttr);

	attrNames = (char **)malloc(numAttr * sizeof(char*));
	dataTypes = (char **)malloc(numAttr * sizeof(char*));
	dt = (DataType *) malloc(numAttr * sizeof(DataType));
	typelength = (int *) malloc(numAttr * sizeof(int));
	keys = (int *) malloc(sizeof(int));
	keyName = (char *) malloc(10*sizeof(char*));

	for(i = 0; i<numAttr; i++)
	{
		attrNames[i] = malloc(sizeof(char *));
		dataTypes[i] =  malloc(10*sizeof(char *));
	}

	switch(numAttr)
	{
		case 1: sscanf(data,"%*s %*s <%*d> %*s (%s: %s) %*s %*s: (%*s)",attrNames[0],dataTypes[0]);
			break;
		case 2: sscanf(data,"%*s (%s: %s, %s: %s) %*s",attrNames[0],dataTypes[0],attrNames[1],dataTypes[1]);
			break;
		case 3: sscanf(data,"%*s %*s <%*d> %*s (%c: %s %c: %s %c: %s) %*s %*s: (%*c)",attrNames[0],dataTypes[0],attrNames[1],dataTypes[1],attrNames[2],dataTypes[2]);
			break;
		case 4: sscanf(data,"%*s (%s: %s, %s: %s, %s: %s, %s: %s) %*s",attrNames[0],dataTypes[0],attrNames[1],dataTypes[1],attrNames[2],dataTypes[2],attrNames[3],dataTypes[3]);
			break;
	}

	for(i = 0; i<numAttr; i++)
	{
		attrNames[i][1] = '\0';
	}


	for(i = 0; i<numAttr; i++)
	{

		memcpy(dataChar,dataTypes[i],sizeof(char));
		switch(*dataChar)
		{
		case 'I': dt[i] = DT_INT;
		typelength[i] = 0;
			break;
		case 'F': dt[i] = DT_FLOAT;
		typelength[i] = 0;
			break;
		case 'B': dt[i] = DT_BOOL;
		typelength[i] = 0;
			break;
		case 'S': dt[i] = DT_STRING;
		memcpy(dataStr,dataTypes[i],10);
		sscanf(dataStr,"STRING[%i]",&typelength[i]);
			break;
		}

	}

	sscanf(data,"%*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %*s (%c)",keyName);

	for(i = 0;i<numAttr;i++)
	{
		if(strcmp(attrNames[i],keyName) == 0)
		{
			keys = &i;
			break;
		}

	}
	//printf("%s %s %s \n",attrNames[0],attrNames[1],attrNames[2]);

	return createSchema (numAttr, attrNames, dt, typelength, 1, keys);
}

//no. of records in a page
int record_count(char *page,char delimiter)
{
	int linecount = 0,i = 0;
	char *ptr;
	ptr = page;

	while(i<PAGE_SIZE)
	{
		if(ptr[i] == delimiter)
		{
			linecount++;
		}
		i++;
	}

	return linecount;
}


//to split the record into separate lines to ease the retrieval of data

char** record_split(char *page,char const *delimiter)
{
	char *line;
	char **records = NULL;
	int linecount = 0,i = 0;
	char *ptr;
	ptr = page;
	char *data = malloc(sizeof(char*) *PAGE_SIZE);

	while(ptr)
	{
		if(*ptr == *delimiter)
		{
			linecount++;
		}
		ptr++;
	}

	records = malloc(linecount*sizeof(char *));
	memcpy(data,page,sizeof(char*) * PAGE_SIZE);

	do
	{
		line = strsep(&data,delimiter);
		*(records + i) = strdup(line);
	}while(line);

	free(data);
	free(line);
	return records;
}

//pad the remaining space with null character
void padRecord(char *record,int totalLength,char delimiter,char padChar)
{
	int i = 0;

	while(i<totalLength)
	{
		if(record[i] != delimiter)
		{
			i++;
		}
		else
		{
			i++;
			break;
		}
	}

	while(i<totalLength)
	{
		record[i] = padChar;
		i++;
	}
}

// table and manager
RC initRecordManager (void *mgmtData)
{
	//in case no management data is received return RC_OK
	//as nothing needs to be handled.
	//initialize buffer manager
	return RC_OK;
}

RC shutdownRecordManager ()
{
	return RC_OK;
}

RC createTable (char *name, Schema *schema)
{
	RC returnCode;
	SM_FileHandle fHandle;
	SM_PageHandle memPage = NULL;

	returnCode = createPageFile(name);
	if(returnCode == RC_OK)
	{
		//after the file is created write the first record as the schema
		//open the file
		returnCode = openPageFile(name,&fHandle);
		memPage = (char*) malloc(PAGE_SIZE*sizeof(char));

		//serialize the schema and write the data to the file as the first record
		memPage = serializeSchema(schema);

		//pad the remaining space with null block
		//padRecord(memPage,PAGE_SIZE,'\n','\0');

		if(returnCode == RC_OK)
		{
			//now writing the code to the first block
			returnCode = writeBlock(0, &fHandle, memPage);
			//free the memory allocated
			free(memPage);
		}
	}

	//schema details to be stored in the file
	//close the file
	closePageFile(&fHandle);
	return returnCode;
}

RC openTable (RM_TableData *rel, char *name)
{
	RC returnCode;
	SM_FileHandle fHandle;
	Buffer_mgr *bufferMgr = malloc(sizeof(Buffer_mgr));

	bufferMgr->bm = MAKE_POOL();
	bufferMgr->h = MAKE_PAGE_HANDLE();

	//just to get the no. of pages in the file
	returnCode = openPageFile(name,&fHandle);
	bufferMgr->totalRecords = fHandle.totalNumPages;
	bufferMgr->insertAt = 0;
	returnCode = closePageFile(&fHandle);
	//since all the insertions and deletions are to be performed using the
	//buffer manager we need to initialize it before performing any operation on the
	//page file
	//with window size of 5 and FIFO replacement strategy
	returnCode = initBufferPool(bufferMgr->bm, name,3, RS_FIFO,NULL);

	if(returnCode == RC_OK)
	{
		rel->name = strdup(bufferMgr->bm->pageFile);
		rel->mgmtData = bufferMgr;
		//get the schema stored at zeroth position
		pinPage(bufferMgr->bm,bufferMgr->h,bufferMgr->insertAt);
		rel->schema = deserializeSchema(bufferMgr->h->data);
		unpinPage(bufferMgr->bm,bufferMgr->h);
		bufferMgr->insertAt = bufferMgr->insertAt + 1;
	}

	return returnCode;
}

RC closeTable (RM_TableData *rel)
{
	RC reasonCode;
	Buffer_mgr *bufferMgr = NULL;

	bufferMgr = rel->mgmtData;
	reasonCode = shutdownBufferPool(bufferMgr->bm);
	return reasonCode;
}

RC deleteTable (char *name)
{
	RC returnCode;
	returnCode = destroyPageFile(name);
	return returnCode;
}

int getNumTuples (RM_TableData *rel)
{
	return 0;
}

// handling records in a table
RC insertRecord (RM_TableData *rel, Record *record)
{
	RC returnCode;
	//char nl = '\n';
	//char *newLine = &nl;
	char *recordIns = NULL;
	//int recordLen = 0,fileRecLen = 0;
	//int rec = 1;
	//char ch;
	Buffer_mgr *bufferMgr = NULL;
	//int recCount = 0;
	//records should be added using the buffer manager
	bufferMgr = rel->mgmtData;
	//rec = bufferMgr->totalRecords;

	//memcpy(&ch,record->data,sizeof(int));
	//rec =  ch- '0';
	//rec = rec +1;
	returnCode = pinPage(bufferMgr->bm,bufferMgr->h,bufferMgr->insertAt);
	if(returnCode != RC_OK)
	{
		return returnCode;
	}
	record->id.page = bufferMgr->insertAt;
	record->id.slot = 1;
	recordIns = serializeRec(record,rel->schema);

	sprintf(bufferMgr->h->data,"%s",recordIns);

	returnCode = markDirty(bufferMgr->bm,bufferMgr->h);
	if(returnCode != RC_OK)
	{
		return returnCode;
	}

	returnCode = unpinPage(bufferMgr->bm,bufferMgr->h);
	if(returnCode != RC_OK)
	{
		return returnCode;

	}
	//returnCode = forcePage (bufferMgr->bm, bufferMgr->h);

	//start scanning records from 1 position and insert where ever there is an empty space
	//for the record
/*
	if(rec == 1)
	{
		returnCode = pinPage(bufferMgr->bm,bufferMgr->h,rec);
		//if total no. of records is only one then it means there are no records
		//as the first record is schema
		recCount = record_count(bufferMgr->h->data,'\n');
		record->id.page = rec;
		if(recCount == 0)
		{
			record->id.slot = 1;
		}
		else
		{
			record->id.slot = recCount +1;;
		}

		recordIns = serializeRec(record,rel->schema);
		//separating every record with a newline character

		strcat(recordIns,newLine);
		if(returnCode != RC_OK)
		{
			return returnCode;
		}
		sprintf(bufferMgr->h->data,"%s",recordIns);
		markDirty(bufferMgr->bm,bufferMgr->h);
		unpinPage(bufferMgr->bm,bufferMgr->h);
		//forceFlushPool(bufferMgr->bm);

	}
	else
	{
		//calculate no. of records already present in the page
		returnCode = pinPage(bufferMgr->bm,bufferMgr->h,rec);
		if(returnCode != RC_OK)
		{
			return returnCode;
		}

		recCount = record_count(bufferMgr->h->data,'\n');
		//check whether last record insert has the space to accommodate the new record
		rec = rec - 1;
		record->id.page = rec;
		record->id.slot = recCount+1;
		recordIns = serializeRec(record,rel->schema);
		recordLen = strlen(recordIns);

		if((fileRecLen + recordLen)>PAGE_SIZE)
		{
			record->id.page = rec +1;
			record->id.slot = 1;
			recordIns = serializeRecord(record,rel->schema);
		}
		strcat(bufferMgr->h->data,recordIns);

		returnCode = markDirty(bufferMgr->bm,bufferMgr->h);
		if(returnCode != RC_OK)
		{
			return returnCode;
		}

		returnCode = unpinPage(bufferMgr->bm,bufferMgr->h);

	}
*/
	free(recordIns);
	printf("Data : %s \n",bufferMgr->h->data);
	bufferMgr->insertAt = bufferMgr->insertAt +1;
	return RC_OK;
}

RC deleteRecord (RM_TableData *rel, RID id)
{
	return RC_OK;
}

RC updateRecord (RM_TableData *rel, Record *record)
{
	return RC_OK;
}

RC getRecord (RM_TableData *rel, RID id, Record *record)
{
	return RC_OK;
}

// scans
RC startScan (RM_TableData *rel, RM_ScanHandle *scan, Expr *cond)
{
	return RC_OK;
}


RC next (RM_ScanHandle *scan, Record *record)
{
	return RC_OK;
}

RC closeScan (RM_ScanHandle *scan)
{
	return RC_OK;
}

// dealing with schemas

int getRecordSize (Schema *schema)
{
	int i;
	int size = 0;

	for(i = 0;i<schema->numAttr;i++)
	{
		size += noOfBytes(schema->dataTypes[i],schema->typeLength[i]);
	}
	return size;
}

Schema *createSchema (int numAttr, char **attrNames, DataType *dataTypes, int *typeLength, int keySize, int *keys)
{
	//declare an object pointer of schema type
	Schema *schemaObj = NULL;
	//allocate memory to the schema
	schemaObj = (Schema *) malloc(sizeof(Schema));
	//copy value to the object pointer
	schemaObj->attrNames = attrNames;
	schemaObj->dataTypes = dataTypes;
	schemaObj->numAttr = numAttr;
	schemaObj->typeLength = typeLength;
	schemaObj->keySize = keySize;
	schemaObj->keyAttrs = keys;

	//returning the object after value assignment
	return schemaObj;

}

RC freeSchema (Schema *schema)
{
	int i = 0;

	for(i = 0;i<schema->numAttr;i++)
	{
		free(schema->attrNames[i]);
	}

	free(schema->typeLength);
	free(schema->keyAttrs);
	free(schema->dataTypes);
	free(schema);

	return RC_OK;

}

RC createRecord (Record **record, Schema *schema)
{
	int i = 0;
	int size = 10;

	Record *localRecord = NULL;
	for(i = 0;i<schema->numAttr;i++)
	{
		size += noOfBytes(schema->dataTypes[i],schema->typeLength[i]);
	}

	localRecord = malloc(sizeof(Record *));
	localRecord->data = (char *) malloc(size * sizeof(char));
	*record = localRecord;

	return RC_OK;
}

RC freeRecord (Record *record)
{

	free(record->data);
	free(record);

	return RC_OK;
}

RC getAttr (Record *record, Schema *schema, int attrNum, Value **value)
{
	RC returnCode;
	char *data = NULL;
	int offset;
	int bytestoCopy = 0;
	Value *val = NULL;

	returnCode = attrOffset (schema,attrNum,&offset);

	bytestoCopy = noOfBytes(schema->dataTypes[attrNum],schema->typeLength[attrNum]);

	data = malloc(bytestoCopy * sizeof(char));
	if(returnCode == RC_OK)
	{

		memcpy(data,(record + offset),bytestoCopy);
		val = stringToValue(data);
		value = &val;
	}
	else
	{
		return RC_INVALID_OFFSET;
	}
	return returnCode;
}

RC setAttr (Record *record, Schema *schema, int attrNum, Value *value)
{
	RC returnCode;
	char *result;
	int offset;
	char *data = NULL;
	int bytestoCopy = 0;

	returnCode = attrOffset (schema,attrNum,&offset);

	result = serializeValue(value);

	bytestoCopy = noOfBytes(schema->dataTypes[attrNum],schema->typeLength[attrNum]);

	if(returnCode == RC_OK)
	{
		data = record->data;

		if(attrNum == 0)
		{
			memcpy(data,result,bytestoCopy * sizeof(char));
		}
		else
		{
			//strcat(data,result);'
			memcpy(data + offset,result,bytestoCopy * sizeof(char));
			//if(attrNum == schema->numAttr - 1)
			//{
			//	data[offset+bytestoCopy+1] = '\0';
			//}
		}

	}
	else
	{
		return RC_INVALID_OFFSET;
	}

	printf("%s \n",data);
	return returnCode;
}
