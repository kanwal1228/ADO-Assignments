/*
 * record_mgr.c
 *
 *  Created on: Apr 6, 2015
 *      Author: kanwal
 */

#include "expr.h"
#include "test_helper.h"
#include "buffer_mgr.h"
#include "storage_mgr.h"
#include "record_mgr.h"


//structure to use the buffer Manager

typedef struct Buffer_mgr
{
	BM_BufferPool *bm;
	BM_PageHandle *h;

}Buffer_mgr;

//no. of bytes to be copied

int noOfBytes(DataType dt,int typeLength)
{
	int bytestoCopy = 0;
	switch (dt)
	{
		case DT_STRING:
		  bytestoCopy = typeLength;
		  break;
		case DT_INT:
		  bytestoCopy = sizeof(int);
		  break;
		case DT_FLOAT:
		  bytestoCopy = sizeof(float);
		  break;
		case DT_BOOL:
		  bytestoCopy = sizeof(bool);
		break;
	}

	return bytestoCopy;
}


//to calculate the offset
//method copied from rm_serializer.c
RC
attrOffset (Schema *schema, int attrNum, int *result)
{
  int offset = 0;
  int attrPos = 0;

  for(attrPos = 0; attrPos < attrNum; attrPos++)
    switch (schema->dataTypes[attrPos])
      {
      case DT_STRING:
	offset += schema->typeLength[attrPos];
	break;
      case DT_INT:
	offset += sizeof(int);
	break;
      case DT_FLOAT:
	offset += sizeof(float);
	break;
      case DT_BOOL:
	offset += sizeof(bool);
	break;
      }

  *result = offset;
  return RC_OK;
}

//deserialize the schema written to the pagefile

Schema* deserializeSchema(char* data)
{
	int numAttr,i;
	char *numattr;
	char **attrNames;
	char *attributeName;
	DataType *dt;
	int *attrSize = NULL;
	int *keys = NULL;
	char* ptr = NULL;

	Schema *schema = NULL;


	ptr = data;

	while(*ptr!= '\0' && *ptr!= '<')
	{
		ptr++;
	}

	numattr = malloc(sizeof(int));

	while(*ptr != '>')
	{
		memcpy(numattr,ptr,sizeof(int));
	}

	numAttr = atoi(numattr);

	attrNames = (char **)malloc(numAttr * sizeof(char*));
	dt = (DataType *) malloc(numAttr * sizeof(DataType));
	attrSize = (int *) malloc(numAttr * sizeof(int));
	keys = (int *) malloc(sizeof(int));


	for(i = 0;i<numAttr;i++)
	{

	}

	while(*ptr!= '\0' && *ptr!= '(')
	{
		ptr++;
	}

	attributeName = ++ptr;





	return schema;
}

//to split the record into separate lines to ease the retrieval of data

char** record_split(char *page,char const *delimiter)
{
	char *line;
	char **records = NULL;
	int linecount = 0,i = 0;
	char *ptr;
	ptr = page;
	char *data = malloc(sizeof(char*) *PAGE_SIZE);

	while(ptr)
	{
		if(*ptr == *delimiter)
		{
			linecount++;
		}
		ptr++;
	}

	records = malloc(linecount*sizeof(char *));
	memcpy(data,page,sizeof(char*) * PAGE_SIZE);

	do
	{
		line = strsep(&data,delimiter);
		*(records + i) = strdup(line);
	}while(line);

	free(data);
	free(line);
	return records;
}

//pad the remaining space with null character
void padRecord(char *record,int totalLength,char padChar)
{
	int i = 0;

	while(i<totalLength)
	{
		if(record[i] != padChar)
		{
			i++;
		}
		else
		{
			record[i] = padChar;
			i++;
		}
	}
}

// table and manager
RC initRecordManager (void *mgmtData)
{
	//in case no management data is received return RC_OK
	//as nothing needs to be handled.
	//initialize buffer manager
	return RC_OK;
}

RC shutdownRecordManager ()
{
	return RC_OK;
}

RC createTable (char *name, Schema *schema)
{
	RC returnCode;
	SM_FileHandle fHandle;
	SM_PageHandle memPage = NULL;

	returnCode = createPageFile(name);
	if(returnCode == RC_OK)
	{
		//after the file is created write the first record as the schema
		//open the file
		returnCode = openPageFile(name,&fHandle);
		memPage = malloc(PAGE_SIZE*sizeof(char *));

		//serialize the schema and write the data to the file as the first record
		memPage = serializeSchema(schema);

		//pad the remaining space with null block
		padRecord(memPage,PAGE_SIZE,'\0');

		if(returnCode == RC_OK)
		{
			//now writing the code to the first block
			returnCode = writeBlock(0, &fHandle, memPage);
			//close the file
			closePageFile(&fHandle);
			//free the memory allocated
			free(memPage);
		}
	}

	//schema details to be stored in the file
	return returnCode;
}

RC openTable (RM_TableData *rel, char *name)
{
	RC returnCode;
	SM_FileHandle fHandle;
	Buffer_mgr bufferMgr;

	bufferMgr.bm = MAKE_POOL();
	bufferMgr.h = MAKE_PAGE_HANDLE();

	returnCode = openPageFile(name,&fHandle);
	//since all the insertions and deletions are to be performed using the
	//buffer manager we need to initialize it before performing any operation on the
	//page file
	//with window size of 5 and FIFO replacement strategy
	returnCode = initBufferPool(bufferMgr.bm, name,5, RS_FIFO,NULL);

	if(returnCode == RC_OK)
	{
		rel->name = strdup(bufferMgr.bm->pageFile);
		rel->mgmtData = &bufferMgr;
	}

	return returnCode;
}

RC closeTable (RM_TableData *rel)
{
	RC reasonCode;
	BM_BufferPool *bm = NULL;
	SM_FileHandle *fHandle = NULL;

	reasonCode = shutdownBufferPool(bm);
	if(reasonCode == RC_OK)
	{
		reasonCode = closePageFile(fHandle);
	}
	return reasonCode;
}

RC deleteTable (char *name)
{
	RC returnCode;
	returnCode = destroyPageFile(name);
	return returnCode;
}

int getNumTuples (RM_TableData *rel)
{
	return 0;
}

// handling records in a table
RC insertRecord (RM_TableData *rel, Record *record)
{
	//records should be added using the buffer manager
	return RC_OK;
}

RC deleteRecord (RM_TableData *rel, RID id)
{
	return RC_OK;
}

RC updateRecord (RM_TableData *rel, Record *record)
{
	return RC_OK;
}

RC getRecord (RM_TableData *rel, RID id, Record *record)
{
	return RC_OK;
}

// scans
RC startScan (RM_TableData *rel, RM_ScanHandle *scan, Expr *cond)
{
	return RC_OK;
}


RC next (RM_ScanHandle *scan, Record *record)
{
	return RC_OK;
}

RC closeScan (RM_ScanHandle *scan)
{
	return RC_OK;
}

// dealing with schemas

int getRecordSize (Schema *schema)
{
	int i;
	int size = 0;

	for(i = 0;i<schema->numAttr;i++)
	{
		size += noOfBytes(schema->dataTypes[i],schema->typeLength[i]);
	}
	return size;
}

Schema *createSchema (int numAttr, char **attrNames, DataType *dataTypes, int *typeLength, int keySize, int *keys)
{
	//declare an object pointer of schema type
	Schema *schemaObj = NULL;
	//allocate memory to the schema
	schemaObj = (Schema *) malloc(sizeof(Schema));
	//copy value to the object pointer
	schemaObj->attrNames = attrNames;
	schemaObj->dataTypes = dataTypes;
	schemaObj->numAttr = numAttr;
	schemaObj->typeLength = typeLength;
	schemaObj->keySize = keySize;
	schemaObj->keyAttrs = keys;

	//returning the object after value assignment
	return schemaObj;

}

RC freeSchema (Schema *schema)
{
	int i = 0;

	for(i = 0;i<schema->numAttr;i++)
	{
		free(schema->attrNames[i]);
	}

	free(schema->typeLength);
	free(schema->keyAttrs);
	free(schema->dataTypes);
	free(schema);

	return RC_OK;

}

RC createRecord (Record **record, Schema *schema)
{
	int i = 0;
	int size = 0;

	Record *localRecord = NULL;
	for(i = 0;i<schema->numAttr;i++)
	{
		size += noOfBytes(*(schema->dataTypes +i),schema->typeLength[i]);
	}

	localRecord = malloc(sizeof(Record *));
	localRecord->data = (char *) malloc(size * sizeof(char));
	*record = localRecord;

	return RC_OK;
}

RC freeRecord (Record *record)
{

	free(record->data);
	free(record);

	return RC_OK;
}

RC getAttr (Record *record, Schema *schema, int attrNum, Value **value)
{
	RC returnCode;
	char *data = NULL;
	int offset;
	int bytestoCopy = 0;
	Value *val = NULL;

	returnCode = attrOffset (schema,attrNum,&offset);

	bytestoCopy = noOfBytes(schema->dataTypes[attrNum],schema->typeLength[attrNum]);

	data = malloc(bytestoCopy * sizeof(char));
	if(returnCode == RC_OK)
	{

		memcpy(data,(record + offset),bytestoCopy);
		val = stringToValue(data);
		value = &val;
	}
	else
	{
		return RC_INVALID_OFFSET;
	}
	return returnCode;
}

RC setAttr (Record *record, Schema *schema, int attrNum, Value *value)
{
	RC returnCode;
	char *result;
	int offset;
	char *data = NULL;
	int bytestoCopy = 0;

	returnCode = attrOffset (schema,attrNum,&offset);

	result = serializeValue(value);

	bytestoCopy = noOfBytes(schema->dataTypes[attrNum],schema->typeLength[attrNum]);

	if(returnCode == RC_OK)
	{
		data = record->data;

		if(attrNum == 0)
		{
			memcpy(data + offset,result,bytestoCopy * sizeof(char));
		}
		else
		{
			strcat(data,result);
		}

	}
	else
	{
		return RC_INVALID_OFFSET;
	}

	return returnCode;
}
