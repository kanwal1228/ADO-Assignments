/*
 * record_mgr.c
 *
 *  Created on: Apr 6, 2015
 *      Author: kanwal
 */
#include "dberror.h"
#include "expr.h"
#include "tables.h"
#include "test_helper.h"
#include "buffer_mgr.h"
#include "storage_mgr.h"
#include "record_mgr.h"


//to convert an array of integers into characters

//to split the record into separate lines to ease the retrieval of data

char** record_split(char *page,char delimiter)
{
	char *line;
	char **records = NULL;
	int linecount = 0,i = 0;
	char *ptr;
	ptr = page;
	char *data = malloc(sizeof(char *) * PAGE_SIZE);

	while(ptr)
	{
		if(*ptr == delimiter)
		{
			linecount++;
		}
		ptr++;
	}

	records = malloc(linecount*sizeof(char *));
	memcpy(data,page,sizeof(char *) * PAGE_SIZE);

	do
	{
		line = strsep(data,delimiter);
		*(records + i) = strdup(line);
	}while(line);

	free(data);
	free(line);
	return records;
}

//pad the remaining space with null character
void padRecord(char *record,int totalLength,char padChar)
{
	int i = 0;

	while(i<totalLength)
	{
		if(record[i] != padChar)
		{
			i++;
		}
		else
		{
			record[i] = padChar;
			i++;
		}
	}
}

// table and manager
RC initRecordManager (void *mgmtData)
{
	//in case no management data is received return RC_OK
	//as nothing needs to be handled.
	//initialize buffer manager
	return RC_OK;
}

RC shutdownRecordManager ()
{
	return RC_OK;
}

RC createTable (char *name, Schema *schema)
{
	RC returnCode;
	SM_FileHandle fHandle;
	SM_PageHandle memPage = NULL;
	int i;
	DataType *dt = NULL;
	int *typeLngth = NULL;
	char dataTypes[10],keyAttr[10],keySize[10],typeLength[10];

	returnCode = createPageFile(name);
	if(returnCode == RC_OK)
	{
		//after the file is created write the first record as the schema
		//open the file
		returnCode = openPageFile(name,&fHandle);
		memPage = malloc(PAGE_SIZE*sizeof(char *));

		//copy the number of attributes
		sprintf(memPage,"%d",schema->numAttr);
		//adding newline character
		strcat(memPage,"\n");

		//copy the attribute Names

		for(i = 0;i<schema->numAttr;i++)
		{
			strcat(memPage,schema->attrNames[i]);
			//adding newline character
			if(i!=schema->numAttr-1)
				strcat(memPage,",");
		}
		strcat(memPage,"\n");

		//copy the data types
		dt = malloc(schema->numAttr * sizeof(int*));
		for(i = 0;i<schema->numAttr;i++)
		{
			dt[i] = schema->dataTypes[i];
			sprintf(dataTypes,"%d",dt[i]);
			strcat(memPage,dataTypes);
			//adding newline character
			if(i!=schema->numAttr-1)
				strcat(memPage,",");
		}
		strcat(memPage,"\n");

		//copy the key attributes
		sprintf(keyAttr,"%d",schema->keyAttrs[0]);
		strcat(memPage,keyAttr);
		//adding newline character
		strcat(memPage,"\n");

		//copy the key size
		sprintf(keySize,"%d",schema->keySize);
		strcat(memPage,keySize);
		//adding newline character
		strcat(memPage,"\n");

		//copy the length of string attributes
		typeLngth = (int *) malloc(schema->numAttr * sizeof(int));
		for(i= 0;i<schema->numAttr;i++)
		{
			memcpy((typeLngth + i),(schema->typeLength + i),(sizeof(int) * 3));
			sprintf(typeLength,"%d",typeLngth[i]);
			strcat(memPage,typeLength);
			//adding newline character
			if(i!=schema->numAttr-1)
				strcat(memPage,",");
		}

		//pad the remaining space with null block
		padRecord(memPage,PAGE_SIZE,'\0');

		if(returnCode == RC_OK)
		{
			//now writing the code to the first block
			returnCode = writeBlock(0, &fHandle, memPage);
			//close the file
			closePageFile(&fHandle);
			//free the memory allocated
			free(memPage);
			//free(typeLngth);
			free(dt);
		}

	}

	//schema details to be stored in the file
	return returnCode;
}

RC openTable (RM_TableData *rel, char *name)
{
	RC returnCode;
	SM_FileHandle fHandle;
	char **records;
	Schema *schema = NULL;
	BM_BufferPool *const bm = MAKE_POOL();
	BM_PageHandle *h = MAKE_PAGE_HANDLE();

	int numAttr;
	char **cpNames;
	DataType *cpDt;
	int *cpSizes;
	int typeLength;
	int cpKeys;
	returnCode = openPageFile(name,&fHandle);

	//since all the insertions and deletions are to be performed using the
	//buffer manager we need to initialize it before performing any operation on the
	//page file
	//with window size of 5 and FIFO replacement strategy
	returnCode = initBufferPool(bm, name,5, RS_FIFO,NULL);

	if(returnCode == RC_OK)
	{
		//read the zeroth record and fill the schema
		pinPage(bm, h, 0);
		records = record_split(h->data,'\n');
		// fill the schema with the data provided using the page handle
		numAttr = atoi(*(records +0));
		cpNames = record_split(*(records +1),',');
		cpDt = record_split(*(records +2),',');
		cpSizes = record_split(records +3,',');
		typeLength = atoi(*(records +4));
		cpKeys = atoi(*(records +5));
		schema = createSchema(numAttr, cpNames, cpDt, cpSizes, typeLength, &cpKeys);

		rel->schema = schema;
		rel->name = strdup(bm->pageFile);
		rel->mgmtData = bm;
	}

	return returnCode;
}

RC closeTable (RM_TableData *rel)
{
	RC reasonCode;
	BM_BufferPool *bm = NULL;
	SM_FileHandle *fHandle = NULL;

	reasonCode = shutdownBufferPool(bm);
	if(reasonCode == RC_OK)
	{
		reasonCode = closePageFile(fHandle);
	}
	return reasonCode;
}

RC deleteTable (char *name)
{
	RC returnCode;
	returnCode = destroyPageFile(name);
	return returnCode;
}

int getNumTuples (RM_TableData *rel)
{

}

// handling records in a table
RC insertRecord (RM_TableData *rel, Record *record)
{

}

RC deleteRecord (RM_TableData *rel, RID id)
{

}

RC updateRecord (RM_TableData *rel, Record *record)
{

}

RC getRecord (RM_TableData *rel, RID id, Record *record)
{

}

// scans
RC startScan (RM_TableData *rel, RM_ScanHandle *scan, Expr *cond)
{

}


RC next (RM_ScanHandle *scan, Record *record)
{

}

RC closeScan (RM_ScanHandle *scan)
{

}

// dealing with schemas

int getRecordSize (Schema *schema)
{

}

Schema *createSchema (int numAttr, char **attrNames, DataType *dataTypes, int *typeLength, int keySize, int *keys)
{
	//declare an object pointer of schema type
	Schema *schemaObj = NULL;
	//allocate memory to the schema
	schemaObj = (Schema *) malloc(sizeof(Schema));
	//copy value to the object pointer
	schemaObj->attrNames = attrNames;
	schemaObj->dataTypes = dataTypes;
	schemaObj->numAttr = numAttr;
	schemaObj->typeLength = typeLength;
	schemaObj->keySize = keySize;
	schemaObj->keyAttrs = keys;

	//returning the object after value assignment
	return schemaObj;

}

RC freeSchema (Schema *schema)
{

}

RC createRecord (Record **record, Schema *schema)
{

}

RC freeRecord (Record *record)
{

}

RC getAttr (Record *record, Schema *schema, int attrNum, Value **value)
{

}

RC setAttr (Record *record, Schema *schema, int attrNum, Value *value)
{

}
