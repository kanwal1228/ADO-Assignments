/*
 * record_mgr.c
 *
 *  Created on: Apr 6, 2015
 *      Author: kanwal
 */

#include "expr.h"
#include "test_helper.h"
#include "buffer_mgr.h"
#include "storage_mgr.h"
#include "record_mgr.h"

// dynamic string
typedef struct VarString {
  char *buf;
  int size;
  int bufsize;
} VarString;

#define MAKE_VARSTRING(var)				\
  do {							\
  var = (VarString *) malloc(sizeof(VarString));	\
  var->size = 0;					\
  var->bufsize = 100;					\
  var->buf = malloc(100);				\
  } while (0)

#define FREE_VARSTRING(var)			\
  do {						\
  free(var->buf);				\
  free(var);					\
  } while (0)

#define GET_STRING(result, var)			\
  do {						\
    result = malloc((var->size) + 1);		\
    memcpy(result, var->buf, var->size);	\
    result[var->size] = '\0';			\
  } while (0)

#define RETURN_STRING(var)			\
  do {						\
    char *resultStr;				\
    GET_STRING(resultStr, var);			\
    FREE_VARSTRING(var);			\
    return resultStr;				\
  } while (0)

#define ENSURE_SIZE(var,newsize)				\
  do {								\
    if (var->bufsize < newsize)					\
    {								\
      int newbufsize = var->bufsize;				\
      while((newbufsize *= 2) < newsize);			\
      var->buf = realloc(var->buf, newbufsize);			\
    }								\
  } while (0)

#define APPEND_STRING(var,string)					\
  do {									\
    ENSURE_SIZE(var, var->size + strlen(string));			\
    memcpy(var->buf + var->size, string, strlen(string));		\
    var->size += strlen(string);					\
  } while(0)

#define APPEND(var, ...)			\
  do {						\
    char *tmp = malloc(10000);			\
    sprintf(tmp, __VA_ARGS__);			\
    APPEND_STRING(var,tmp);			\
    free(tmp);					\
  } while(0)




//structure to use the buffer Manager

typedef struct Buffer_mgr
{
	BM_BufferPool *bm;
	BM_PageHandle *h;
	int totalRecords;
	int insertAt;

}Buffer_mgr;

char * serializeRec(Record *record, Schema *schema)
{
  VarString *result;
  MAKE_VARSTRING(result);
  int i;

  APPEND(result, "[%i-%i] (", record->id.page, record->id.slot);

  for(i = 0; i < schema->numAttr; i++)
    {
	  APPEND(result, "%s", (i == 0) ? "" : ",");
      APPEND_STRING(result, serializeAttr (record, schema, i));
    }

  APPEND_STRING(result, ")");

  RETURN_STRING(result);
}


//no. of bytes to be copied

int noOfBytes(DataType dt,int typeLength)
{
	int bytestoCopy = 0;
	switch (dt)
	{
		case DT_STRING:
		  bytestoCopy = typeLength;
		  break;
		case DT_INT:
		  bytestoCopy = sizeof(int);
		  break;
		case DT_FLOAT:
		  bytestoCopy = sizeof(float);
		  break;
		case DT_BOOL:
		  bytestoCopy = sizeof(bool);
		break;
	}

	return bytestoCopy;
}


//to calculate the offset
//method copied from rm_serializer.c
RC
attrOffset (Schema *schema, int attrNum, int *result)
{
  int offset = 0;
  int attrPos = 0;

  for(attrPos = 0; attrPos < attrNum; attrPos++)
    switch (schema->dataTypes[attrPos])
      {
      case DT_STRING:
	offset += ( schema->typeLength[attrPos]);
	break;
      case DT_INT:
	offset += sizeof(int);
	break;
      case DT_FLOAT:
	offset += sizeof(float);
	break;
      case DT_BOOL:
	offset += sizeof(bool);
	break;
      }

  *result = offset;
  return RC_OK;
}

//deserialize the schema written to the pagefile

Schema* deserializeSchema(char* data)
{
	int numAttr,i;
	char **attrNames;
	char *keyName;
	char **dataTypes;
	DataType *dt;
	int *keys = NULL;
	int *typelength;

	char *dataChar = malloc(sizeof(char));
	char dataStr[10];

	sscanf(data,"%*s %*s <%d> %*s",&numAttr);

	attrNames = (char **)malloc(numAttr * sizeof(char*));
	dataTypes = (char **)malloc(numAttr * sizeof(char*));
	dt = (DataType *) malloc(numAttr * sizeof(DataType));
	typelength = (int *) malloc(numAttr * sizeof(int));
	keys = (int *) malloc(sizeof(int));
	keyName = (char *) malloc(10*sizeof(char*));

	for(i = 0; i<numAttr; i++)
	{
		attrNames[i] = malloc(sizeof(char *));
		dataTypes[i] =  malloc(10*sizeof(char *));
	}

	switch(numAttr)
	{
		case 1: sscanf(data,"%*s %*s <%*d> %*s (%s: %s) %*s %*s: (%*s)",attrNames[0],dataTypes[0]);
			break;
		case 2: sscanf(data,"%*s (%s: %s, %s: %s) %*s",attrNames[0],dataTypes[0],attrNames[1],dataTypes[1]);
			break;
		case 3: sscanf(data,"%*s %*s <%*d> %*s (%c: %s %c: %s %c: %s) %*s %*s: (%*c)",attrNames[0],dataTypes[0],attrNames[1],dataTypes[1],attrNames[2],dataTypes[2]);
			break;
		case 4: sscanf(data,"%*s (%s: %s, %s: %s, %s: %s, %s: %s) %*s",attrNames[0],dataTypes[0],attrNames[1],dataTypes[1],attrNames[2],dataTypes[2],attrNames[3],dataTypes[3]);
			break;
	}

	for(i = 0; i<numAttr; i++)
	{
		attrNames[i][1] = '\0';
	}


	for(i = 0; i<numAttr; i++)
	{

		memcpy(dataChar,dataTypes[i],sizeof(char));
		switch(*dataChar)
		{
		case 'I': dt[i] = DT_INT;
		typelength[i] = 0;
			break;
		case 'F': dt[i] = DT_FLOAT;
		typelength[i] = 0;
			break;
		case 'B': dt[i] = DT_BOOL;
		typelength[i] = 0;
			break;
		case 'S': dt[i] = DT_STRING;
		memcpy(dataStr,dataTypes[i],10);
		sscanf(dataStr,"STRING[%i]",&typelength[i]);
			break;
		}

	}

	sscanf(data,"%*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %*s (%c)",keyName);

	for(i = 0;i<numAttr;i++)
	{
		if(strcmp(attrNames[i],keyName) == 0)
		{
			keys = &i;
			break;
		}

	}
	//printf("%s %s %s \n",attrNames[0],attrNames[1],attrNames[2]);

	return createSchema (numAttr, attrNames, dt, typelength, 1, keys);
}

//no. of records in a page
int record_count(char *page,char delimiter)
{
	int linecount = 0,i = 0;
	char *ptr;
	ptr = page;

	while(i<strlen(page))
	{
		if(ptr[i] == delimiter)
		{
			linecount++;
		}
		i++;
	}
	return linecount;
}


//to split the record into separate lines to ease the retrieval of data

char** record_split(char *page,char const *delimiter)
{
	char *line;
	char **records = NULL;
	int linecount = 0,i = 0;
	char *ptr;
	int MAX;
	ptr = page;
	//int offset=0;

	MAX = strlen(page);
	char *data = malloc(sizeof(char) *MAX-2);

	for(i = 0;i<MAX;i++)
	{
		if(ptr[i] == *delimiter)
		{
			linecount++;
		}
	}
	linecount++;
	records = malloc(linecount*sizeof(char *));
	memcpy(data,page,(sizeof(char*)*2));
	//data[MAX]="\0";
	i= 0;
	do
	{
		line = strsep(&data,delimiter);
		records[i] = strdup(line);
		i++;
	}while(i<linecount);

	return records;
}

//pad the remaining space with null character
void padRecord(char *record,int totalLength,char delimiter,char padChar)
{
	int i = 0;

	while(i<totalLength)
	{
		if(record[i] != delimiter)
		{
			i++;
		}
		else
		{
			i++;
			break;
		}
	}

	while(i<totalLength)
	{
		record[i] = padChar;
		i++;
	}
}

// table and manager
RC initRecordManager (void *mgmtData)
{
	//in case no management data is received return RC_OK
	//as nothing needs to be handled.
	//initialize buffer manager
	return RC_OK;
}

RC shutdownRecordManager ()
{
	return RC_OK;
}

RC createTable (char *name, Schema *schema)
{
	RC returnCode;
	SM_FileHandle fHandle;
	SM_PageHandle memPage = NULL;

	returnCode = createPageFile(name);
	if(returnCode == RC_OK)
	{
		//after the file is created write the first record as the schema
		//open the file
		returnCode = openPageFile(name,&fHandle);
		memPage = (char*) malloc(PAGE_SIZE*sizeof(char));

		//serialize the schema and write the data to the file as the first record
		memPage = serializeSchema(schema);

		//pad the remaining space with null block
		//padRecord(memPage,PAGE_SIZE,'\n','\0');

		if(returnCode == RC_OK)
		{
			//now writing the code to the first block
			returnCode = writeBlock(0, &fHandle, memPage);
			//free the memory allocated
			free(memPage);
		}
	}

	//schema details to be stored in the file
	//close the file
	closePageFile(&fHandle);
	return returnCode;
}

RC openTable (RM_TableData *rel, char *name)
{
	RC returnCode;
	SM_FileHandle fHandle;
	Buffer_mgr *bufferMgr = malloc(sizeof(Buffer_mgr));

	bufferMgr->bm = MAKE_POOL();
	bufferMgr->h = MAKE_PAGE_HANDLE();

	//just to get the no. of pages in the file
	returnCode = openPageFile(name,&fHandle);
	bufferMgr->totalRecords = fHandle.totalNumPages;
	bufferMgr->insertAt = 0;
	returnCode = closePageFile(&fHandle);
	//since all the insertions and deletions are to be performed using the
	//buffer manager we need to initialize it before performing any operation on the
	//page file
	//with window size of 5 and FIFO replacement strategy
	returnCode = initBufferPool(bufferMgr->bm, name,3, RS_FIFO,NULL);

	if(returnCode == RC_OK)
	{
		rel->name = strdup(bufferMgr->bm->pageFile);
		rel->mgmtData = bufferMgr;
		//get the schema stored at zeroth position
		pinPage(bufferMgr->bm,bufferMgr->h,bufferMgr->insertAt);
		rel->schema = deserializeSchema(bufferMgr->h->data);
		unpinPage(bufferMgr->bm,bufferMgr->h);
		bufferMgr->insertAt = bufferMgr->insertAt + 1;
	}

	return returnCode;
}

RC closeTable (RM_TableData *rel)
{
	RC reasonCode;
	Buffer_mgr *bufferMgr = NULL;

	bufferMgr = rel->mgmtData;
	reasonCode = shutdownBufferPool(bufferMgr->bm);
	free(bufferMgr->bm);
	free(bufferMgr->h);
	return reasonCode;
}

RC deleteTable (char *name)
{
	RC returnCode;
	returnCode = destroyPageFile(name);
	return returnCode;
}

int getNumTuples (RM_TableData *rel)
{
	return 0;
}

// handling records in a table
RC insertRecord (RM_TableData *rel, Record *record)
{
	RC returnCode;
	Buffer_mgr *bufferMgr = NULL;

	//records should be added using the buffer manager
	bufferMgr = rel->mgmtData;

	returnCode = pinPage(bufferMgr->bm,bufferMgr->h,bufferMgr->insertAt);
	if(returnCode != RC_OK)
	{
		return returnCode;
	}
	record->id.page = bufferMgr->insertAt;
	record->id.slot = 1;

	sprintf(bufferMgr->h->data,"%s",record->data);

	returnCode = markDirty(bufferMgr->bm,bufferMgr->h);
	if(returnCode != RC_OK)
	{
		return returnCode;
	}

	returnCode = unpinPage(bufferMgr->bm,bufferMgr->h);
	if(returnCode != RC_OK)
	{
		return returnCode;

	}

	printf("Data : %s \n",bufferMgr->h->data);
	bufferMgr->insertAt = bufferMgr->insertAt +1;
	return RC_OK;
}

RC deleteRecord (RM_TableData *rel, RID id)
{
	Buffer_mgr *bufferMgr = NULL;
	bufferMgr = rel->mgmtData;
	RC returnCode;

	returnCode = pinPage(bufferMgr->bm,bufferMgr->h,id.page);
	if(returnCode != RC_OK)
	{
		return returnCode;
	}

	memset(bufferMgr->h->data,'\0',strlen(bufferMgr->h->data));

	returnCode = markDirty(bufferMgr->bm,bufferMgr->h);
	if(returnCode != RC_OK)
	{
		return returnCode;
	}

	returnCode = unpinPage(bufferMgr->bm,bufferMgr->h);
	if(returnCode != RC_OK)
	{
		return returnCode;

	}
	return RC_OK;
}

RC updateRecord (RM_TableData *rel, Record *record)
{
	Buffer_mgr *bufferMgr = NULL;
	bufferMgr = rel->mgmtData;
	RC returnCode;

	returnCode = pinPage(bufferMgr->bm,bufferMgr->h,record->id.page);
	if(returnCode != RC_OK)
	{
		return returnCode;
	}

	sprintf(bufferMgr->h->data,"%s",record->data);

	returnCode = markDirty(bufferMgr->bm,bufferMgr->h);
	if(returnCode != RC_OK)
	{
		return returnCode;
	}

	returnCode = unpinPage(bufferMgr->bm,bufferMgr->h);
	if(returnCode != RC_OK)
	{
		return returnCode;

	}

	return RC_OK;
}

RC getRecord (RM_TableData *rel, RID id, Record *record)
{
	RC returnCode;
	Buffer_mgr *bufferMgr = NULL;
	bufferMgr = rel->mgmtData;


	returnCode = pinPage(bufferMgr->bm, bufferMgr->h,id.page);
	if(returnCode != RC_OK)
	{
		return returnCode;
	}

	record->data = bufferMgr->h->data;
	record->id.page = id.page;
	record->id.slot = id.slot;

	printf("%s \n",record->data);

	returnCode = unpinPage(bufferMgr->bm, bufferMgr->h);

	return returnCode;
}

// scans
RC startScan (RM_TableData *rel, RM_ScanHandle *scan, Expr *cond)
{
	return RC_OK;
}


RC next (RM_ScanHandle *scan, Record *record)
{
	return RC_OK;
}

RC closeScan (RM_ScanHandle *scan)
{
	return RC_OK;
}

// dealing with schemas

int getRecordSize (Schema *schema)
{
	int i;
	int size = 0;

	for(i = 0;i<schema->numAttr;i++)
	{
		size += noOfBytes(schema->dataTypes[i],schema->typeLength[i]);
	}
	return size;
}

Schema *createSchema (int numAttr, char **attrNames, DataType *dataTypes, int *typeLength, int keySize, int *keys)
{
	//declare an object pointer of schema type
	Schema *schemaObj = NULL;
	//allocate memory to the schema
	schemaObj = (Schema *) malloc(sizeof(Schema));
	//copy value to the object pointer
	schemaObj->attrNames = attrNames;
	schemaObj->dataTypes = dataTypes;
	schemaObj->numAttr = numAttr;
	schemaObj->typeLength = typeLength;
	schemaObj->keySize = keySize;
	schemaObj->keyAttrs = keys;

	//returning the object after value assignment
	return schemaObj;

}

RC freeSchema (Schema *schema)
{
	int i = 0;

	for(i = 0;i<schema->numAttr;i++)
	{
		free(schema->attrNames[i]);
	}

	free(schema->typeLength);
	free(schema->keyAttrs);
	free(schema->dataTypes);
	free(schema);

	return RC_OK;

}

RC createRecord (Record **record, Schema *schema)
{
	int i = 0;
	int size = 10;

	Record *localRecord = NULL;
	for(i = 0;i<schema->numAttr;i++)
	{
		size += noOfBytes(schema->dataTypes[i],schema->typeLength[i]);
	}

	localRecord = malloc(sizeof(Record));
	localRecord->data = (char *) malloc((size +1) * sizeof(char));

	memset(localRecord->data,'\0',(size +1) * sizeof(char));

	*record = malloc(sizeof(Record ));
	memcpy(*record,localRecord,sizeof(Record));
	free(localRecord);

	return RC_OK;
}

RC freeRecord (Record *record)
{
	free(record->data);
	free(record);
	return RC_OK;
}

RC getAttr (Record *record, Schema *schema, int attrNum, Value **value)
{
	char ch = ',';
	Value *val = NULL;
	char *rec = NULL;
	char *delimiter;
	char **data = NULL;
	delimiter = malloc(sizeof(char));
	delimiter  = &ch;
	rec = strdup(record->data + 1);
	data =  record_split(rec,delimiter);

	val = (Value *) malloc(sizeof(Value));
	switch(schema->dataTypes[attrNum])
	{
		case DT_INT:
			val->dt = schema->dataTypes[attrNum];
			val->v.intV = atoi(data[attrNum]);

		  break;
		case DT_FLOAT:
			val->dt = schema->dataTypes[attrNum];
			val->v.floatV = atof(data[attrNum]);

		  break;
		case DT_STRING:
			val->dt = schema->dataTypes[attrNum];
			val->v.stringV = strdup( data[attrNum]);
		  break;
		case DT_BOOL:
			val->dt = schema->dataTypes[attrNum];
			val->v.boolV = (data[attrNum] == 0)?TRUE:FALSE ;
		  break;
	}

	free(rec);
	*value = val;
	return RC_OK;
}

RC setAttr (Record *record, Schema *schema, int attrNum, Value *value)
{
	int i = 0;
	char ch = ',';
	char *delimiter = NULL;
	char *data = NULL;
	char *val;
	char *pos = NULL;
	int index = 0;
	char *tmp;
	int recCount = 0;

	data = record->data;
	delimiter = malloc(sizeof(char));
	delimiter  = &ch;
	tmp = malloc(sizeof(char)*strlen(data));
	memset(tmp,'\0',sizeof(char)*strlen(data));

	switch(schema->dataTypes[attrNum])
	{
		case DT_INT:
			val = malloc(sizeof(int));
			sprintf(val,"%i",value->v.intV);
	      break;
	    case DT_FLOAT:
	    	val = malloc(sizeof(float));
	    	sprintf(val,"%f", value->v.floatV);
	      break;
	    case DT_STRING:
	    	val = malloc(schema->typeLength[attrNum]);
	    	sprintf(val,"%s", value->v.stringV);
	    	val[strlen(val)] = '\0';
	      break;
	    case DT_BOOL:
	    	val = malloc(sizeof(int));
	    	sprintf(val,"%i",value->v.boolV);
	      break;
	}

	if(data[0] !='[')
	{
		sprintf(data,"[%s,",val);
	}
	else
	{
		if(attrNum == 0)
		{
			strcpy(data+1,val);
		}
		else
		{
			recCount = record_count(data,*delimiter);

			for(i=1;i<=recCount;i++)
			{
				pos = strchr(data + index,ch);
				index = pos-data+1;
			}

			strncpy(tmp,data,index);
			strcpy(tmp + index,val);
			//memset(data,'\0',strlen(data));
			memcpy(data,tmp,strlen(tmp));
		}

		if(attrNum == schema->numAttr -1)
		{
			data[strlen(data)] = ']';
			data[strlen(data) + 1] = '\0';
		}
		else
		{
			data[strlen(data)] = ch;
		}

	}

	//free(tmp);
	free(val);
	return RC_OK;
}
